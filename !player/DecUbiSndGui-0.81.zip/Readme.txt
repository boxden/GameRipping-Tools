DecUbiSndGui is a graphical program to decode the audio streams found in many UbiSoft games.

Feel free to use the source code in your project. If you do, credit is appreciated but not required.

Coded by Zench of the XeNTaX forums (forum.xentax.com).
Special thanks go to (in no particular order): Kataah, OrangeC, Mirrodin, Nikson, and many others of the XeNTaX forums.