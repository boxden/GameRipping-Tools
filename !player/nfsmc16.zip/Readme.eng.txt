            Need for Speed Multimedia Converter
                       Version 1.6

            Copyright (c) 2006-2010 CTPAX-X Team


   General Information
   ===================

This program is used for converting music and video from the
Need For Speed game series.


   Converting Music
   ================

Music can be converted into WAV or MP3 format.

List of supported games:
        - Hot Pursuit 2
        - Underground
        - Underground 2
        - Most Wanted
        - Carbon
        - ProStreet
        - Undercover
        - Hot Pursuit 2010

Warning!
Converting of interactive music from NFS Most Wanted,
Carbon and Undercover is not supported.


   Converting Video
   ================

Video can be converted only into AVI format.
For correct playing you need to download and install VP6 codec.
You can get it from this web site:
http://www.free-codecs.com/download/VP6.htm

List of supported games: 
        - Underground 2
        - Most Wanted
        - Carbon

In NFS Carbon almost all movies have multichannel audiotrack.
For correct playing multichannel audio you need to install
DirectShow filter, which supports multichannel audiostream.
We recommend to use AC3Filter. You can get AC3Filter from:
http://www.ac3filter.net


   Program uses following 3rd-party technologies
   =============================================

- EA's Video & Audio Decoder v0.6i *BETA*
  Copyright (c) 2005-2007 by VAG, ARR

- MP3 LAME Codec v3.98.4
  http://www.mp3dev.org

- Audio Tools Library v1.9
  Copyright (c) 2001, 2002 by Jurgen Faul
  http://jfaul.de/atl

- LENIN INC WIN32API Library v1.0 (TAboutScroller class)
  Copyright (c) 2002-2005 by Vladimir Drigalkin, LENIN INC
  http://www.lenininc.com


   Contacts
   ========

Web Site: www.ctpax-x.ru
E-mail  : support@ctpax-x.ru


   History
   =======

Version 1.6
  [+] Hot Pursuit 2010 music is supported now
  [+] Added information about one Undercover's songs and fix for two other ones
  [+] Updated lame encoder to 3.98.4

Version 1.5.1
  [+] Added information about four Undercover's songs
  [+] Changed program icon

Version 1.5
  [+] Undercover music is supported now

Version 1.4
  [+] ProStreet music is supported now

Version 1.3.1
  [+] Fixed work with different versions of NFS - U2
  [+] Fixed bug with saving settings in the registry

Version 1.3
  [+] Hot Pursuit 2, Underground, Underground 2, Most Wanted are supported now
  [+] New interface
  [+] MP3 quality settings were added

Version 1.2
  [+] VP6 video converting is supported now

Version 1.1
  [+] Fixed work with folders with national chars

Version 1.0
  [!] First release


EOF
