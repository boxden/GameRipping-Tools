#!/bin/sh

git apply ffmpeg-revert-bcrypt-random.patch
