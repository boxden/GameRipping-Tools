WSS File Converter v1.0 README
------------------------------

This program was written for the OFP community to convert
BIS�s wss soundfiles to wav format and vice versae.

This program used to be based on two DOS applications called wsscod and
wssdec. It used to serve as a GUI for these progs to save the annoying
command line inputs.
there was, however, the problem that filepaths needed to be converted to
8.3 format, which caused a bug in the application because i did not do it. 
Instead of adding this feature, i implemented file conversion routines to get rid of
the DOS utilities.

USAGE:
------

- To convert wav-files into wss, click the "wss encode" button. If you want
  the source wav-files to be deleted after encoding, check the "Delete wav files after encode"
  box.
  Select one or multiple files in the "File Open" dialog and click ok to start conversion.
  
- To convert wss-files into wav, click the "wss decode" button and select files to be
  converted from the "File Open" dialog and click ok to start conversion.

- When conversion is done, the conversion list will show extended information.
  If a file could not be convertet, a " - " will be prefixed to the filename.
  Successfully converted files are marked " + ".

- The converted files will be created in the same directory as the source files.
  If a file with the same filename already exists in the directory, it will be replaced
  by the new file.

NOTES ON AUDIOFILES:
--------------------

OperationFlashpoint(tm) uses Microsofts DirectSound runtime to playback sounds.
DirectSound is only capable of playing back sound PCM data, which is an uncompressed
format.
The most common format types are:
- sample rate: 11,025 / 22,05 / 44,1 kHz
- bit depth: 8 / 16
- channels: mono / stereo

Other format types (e.g. 24bit/sample) might also be supported, but this depends on the audio hardware.

If the sound is a 3D-sound (in flashpoint, all sounds except radio and music), it has to be a mono file,
because stereo impression is generated dynamically by the DirectSound engine.

Thus, using ogg-files for flashpoint only makes sense for music, environment sounds and (maybe) radio.
ogg-compressed files only reduce resource size, but flashpoint must convert these files to PCM before using
them, so loading the file may reduce performance due to the required conversion process.
  

cheerz
Stoppelhopser

comments and bug reports may be send to: stoppel_hopser@gmx.de

DISCLAIMER
!!!!!!!!!!
This program is freeware and to be used at your own risk.
The author cannot be held responsible for any damage usage
of this program may cause to your system.
