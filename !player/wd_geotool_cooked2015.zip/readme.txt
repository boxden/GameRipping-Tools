PC died late last year here is what i could recover, if this doesnt work on a model don't
bug me for a solution I will simply ignore you be glad i even bothered to release this.
-Cra0